# DemonGirls
Helltaker demake for Gamebuino Meta.

https://gamebuino.com/fr

This is a puzzle game inspired by the famous « Sokoban », with a little more complexity.

« When demon girls are involved, no price is high enough. » You said, as you ventured down to Hell.

This is the story of the Helltaker, a guy who passes deadly trials to date horny horned ladies.

The original game was made by VanRipper (free on Steam: https://store.steampowered.com/app/1289310/Helltaker/)

« Demon Girls » t-shirts are available.
New levels in Heaven are now available.

You can make your own levels or graphics by modifying the source code.

Thank you for playing, and take a look at my other artworks: http://www.juicelizard.com/

Contact: juice.lizard@hotmail.fr

This is a fangame and VanRipper did not work on it.
