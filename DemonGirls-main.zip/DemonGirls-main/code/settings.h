#pragma once

#define NB_ROWS_LEVELS    10
#define NB_COLUMNS_LEVELS 11
#define TOTAL_LEVELS      10
