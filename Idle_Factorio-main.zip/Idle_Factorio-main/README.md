# Idle_Factorio

An idle game demo, adapted from the video game Factorio.
